//
// Created by cherit on 12/27/19.
//

#ifndef PROJECT_IPC_FILES_H
#define PROJECT_IPC_FILES_H
int read_to_char(int file, char separator, char** string);
int get_line(int file, char** string);
#endif //PROJECT_IPC_FILES_H
